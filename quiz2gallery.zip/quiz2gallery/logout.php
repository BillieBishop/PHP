<?php

require_once 'db.php';
unset($_SESSION['user']);

?>

<h1>Logged out</h1>
<a href ="index.php">Click to continue</a>

